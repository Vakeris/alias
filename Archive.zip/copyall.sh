#!/bin/bash
echo "Copying files"
cp -r kservices5 ~/.local/share/kservices5
cp -r Scripts ~/
echo "Icon=$(echo ~)/.local/share/kservices5/ServiceMenus/icons/davinci.png" >> ~/.local/share/kservices5/ServiceMenus/ConvertToMov.desktop
echo "Icon=$(echo ~)/.local/share/kservices5/ServiceMenus/icons/davinci.png" >> ~/.local/share/kservices5/ServiceMenus/ConvertToMp4.desktop
echo "Icon=$(echo ~)/.local/share/kservices5/ServiceMenus/icons/davinci.png" >> ~/.local/share/kservices5/ServiceMenus/RemoveAudio.desktop
echo "Icon=$(echo ~)/.local/share/kservices5/ServiceMenus/icons/davinci.png" >> ~/.local/share/kservices5/ServiceMenus/ExtractAudio.desktop
echo "Icon=$(echo ~)/.local/share/kservices5/ServiceMenus/icons/image.png" >> ~/.local/share/kservices5/ServiceMenus/SvgToPng.desktop
echo "Icon=$(echo ~)/.local/share/kservices5/ServiceMenus/icons/image.png" >> ~/.local/share/kservices5/ServiceMenus/WebpToJpg.desktop
chmod -R +x ~/Scripts/
echo "All Finished !"
